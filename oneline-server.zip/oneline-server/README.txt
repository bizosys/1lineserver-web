1 - Copy oneline.sqlite to right location.
2 - Copy jdbc.conf to /etc/jdbc.conf with proper permissions
3 - Open /etc/jdbc.conf and setup database pool (Leave the config pool now)
4 - Set approperiately <connectionUrl>    oneline.sqlite  path
